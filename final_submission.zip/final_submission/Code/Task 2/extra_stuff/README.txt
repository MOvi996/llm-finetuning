task2.py is the required submission file. Runs on cluster as required.

task2_cheatVersion.ipynb is a (successful) experiment we used to generate results on colab
when we couldn't figure out how to use the cluster. It is redundant next to the proper .py
file, but we thought it was still worth sharing with you.

